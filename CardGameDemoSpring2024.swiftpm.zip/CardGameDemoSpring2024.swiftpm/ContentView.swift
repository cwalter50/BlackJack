import SwiftUI

struct ContentView: View {
//    @State var card: Card = Card(suit: "hearts", value: 10, symbol: "Q")
    @State var deck: Deck = Deck()
    @State var playerCards: [Card] = []
    @State var dealerCards: [Card] = []
    
    @State var gameOver: Bool = false
    

    @State var showEndGameAlert: Bool = false
    @State var alertMessage: String = ""
    
    
    var dealerShowingScore: Int {
        if dealerCards.count > 1 {
            return dealerCards[1].value
        } else {
            return 0
        }
    }
    var dealerScore: Int {
        var total = 0
        for card in dealerCards {
            total += card.value
        }
        var aceCount = 0
        for card in dealerCards {
            if card.symbol == "A" {
                aceCount += 1
            }
        }
        while aceCount > 0 && total > 21 {
            total -= 10
            aceCount -= 1
        }
        return total
    }
    var playerScore: Int {
        var total = 0
        for card in playerCards {
            total += card.value
        }
        var aceCount = 0
        for card in playerCards {
            if card.symbol == "A" {
                aceCount += 1
            }
        }
        while aceCount > 0 && total > 21 {
            total -= 10
            aceCount -= 1
        }
        return total
    }
    
    
    var body: some View {
        VStack {
            Text(gameOver == false ? "Dealer Showing: \(dealerShowingScore)" : "Dealer: \(dealerScore)")
            HStack {
                ForEach(0..<dealerCards.count, id: \.self) { i in
                    Image((gameOver == false && i == 0) ? "card_back": dealerCards[i].imageName)
                        .resizable()
                        .frame(height:140)
                        .frame(maxWidth: 120)
                }
                
            }
            HStack(spacing: 15) {
                Button(action: {
                    // card = deck.dealCard()
                    let newCard = deck.dealCard()
                    print(newCard.value)
                    playerCards.append(newCard)
                    didPlayerBust()
                }, label: {
                    Text("Hit")
                        .padding()
                        .frame(width: 100, height: 80)
                        .background(
                            RoundedRectangle(cornerRadius: 15).foregroundColor(.green).opacity(0.3)
                        )
                })
               
                Button(action: {
                    gameOver = true
                    while dealerScore < 16 {
                        withAnimation(.spring(.bouncy, blendDuration: 2)) { 
                            dealerCards.append(deck.dealCard()) 
                        }
                    }
                    checkForWinner()
                    
                    
                }, label: {
                    Text("Stand")
                        .padding()
                        .frame(width: 120, height: 80)
                        .background(
                            RoundedRectangle(cornerRadius: 15).foregroundColor(.red).opacity(0.3)
                        )
                })
                Button(action: {
                    newGame()
                    gameOver = false
                
                }, label: {
                    Text("New Game")
                        .padding()
                        .frame(width: 170, height: 80)
                        .font(.title)
                        .background(
                            RoundedRectangle(cornerRadius: 15).foregroundColor(.orange).opacity(0.3)
                        )
                })
            }
            
            HStack(spacing: 2) {
                ForEach(playerCards) { card in
                    Image(card.imageName)
                        .resizable()
                        .frame(height:140)
                        .frame(maxWidth: 120)
                }
            }
            Text("Player: \(playerScore)")
                .font(.largeTitle)
            Spacer()
            
        }
        .padding()
        .font(.largeTitle)
        .onAppear(perform: {
            newGame()
        })
        .alert(alertMessage, isPresented: $showEndGameAlert) { 
            Button("OK") {
                newGame()
            }
        }
    }
    
    func newGame() {
        gameOver = false
        dealerCards.removeAll()
        playerCards.removeAll()
        
//        deck.loadCards()
        
        playerCards.append(deck.dealCard())
        playerCards.append(deck.dealCard())
        
        dealerCards.append(deck.dealCard())
        dealerCards.append(deck.dealCard())
    }
    
    func didPlayerBust() {
        if playerScore > 21 {
            alertMessage = "You Went over 21 and lost 🥲"
            showEndGameAlert = true
        }
    }
    
    func checkForWinner() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            if playerScore > dealerScore {
                alertMessage = "You won 💰💰💰"
            } else if playerScore == dealerScore {
                alertMessage = "You Tied"
            } else {
                alertMessage = "You Lost 💸💸💸"
            }
            showEndGameAlert = true
        }
        
    }
    
}
